import React, { Fragment } from 'react';
import {Table} from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.min.css";
import OrderDetails from './OrderDetails';
import Header from './Header';

function Orders(){

   
     return(
        
        <Fragment>
            <Header />
            <div style={{margin:"2rem"}}>
               <Table striped bordered hover className="border border-4 border-dark">
                <thead>
                    <tr>
                    <th>
                            Name
                        </th>
                        <th>
                            Contact
                        </th>
                        <th>
                            Product
                        </th>
                        <th>
                            Price
                        </th>
                        <th>
                            Quantity
                        </th>
                        
                    </tr>
                </thead>
                <tbody>
                    {
                        OrderDetails && OrderDetails.length > 0?
                        OrderDetails.map((item) =>{
                            return(
                                <tr>
                                    <td>
                                        {item.PersonName}
                                    </td>
                                    <td>
                                        {item.ContactNumber}
                                    </td>
                                    <td>
                                        {item.Name}
                                    </td>
                                    <td>
                                        {item.Price}
                                    </td>
                                    <td>
                                        {item.Quantity}
                                    </td>
                                </tr>
                            )
                        })
                        :
                        "No record"
                    }
                </tbody>
               </Table>

               <br>
               </br>

            </div>
        </Fragment>
     );
}

export default Orders;