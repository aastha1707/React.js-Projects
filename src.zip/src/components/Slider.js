import React, { Component } from 'react';
import { Carousel } from 'react-bootstrap';
class Slider extends Component {
    render() {
        return (
            <div className='container-fluid p-5'>
                <Carousel>
                    <Carousel.Item>
                        <img className="d-block w-100" src={'https://www.fnp.com/images/pr/l/v20221214145702/chocolaty-truffle-cake-half-kg-eggless_1.jpg'} width="250vw" height="470vh" />

                        <Carousel.Caption>
                            <h1>Cake is here</h1>
                           
                        </Carousel.Caption>


                    </Carousel.Item>

                    <Carousel.Item>
                        <img className="d-block w-100" src={'https://www.fnp.com/images/pr/l/v20221205144829/red-velvet-fresh-cream-cake-half-kg_1.jpg'} width="500vw" height="600vh" />

                        <Carousel.Caption>
                            <h1>Unlimited Stock</h1>
                            
                        </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item>
                        <img className='d-block w-100' src={'https://www.fnp.com/images/pr/l/v20221201132736/rose-fondant-cake-chocolate-4kg_2.jpg'} width="500vw" height="600vh" />
                        <Carousel.Caption>
                            <h1>Monsoon is here</h1>
                            
                        </Carousel.Caption>
                    </Carousel.Item>
                </Carousel>
            </div>
        );
    }
}
export default Slider