const OrderDetails = [
    {
     PersonName:"Anuj",
     ContactNumber: "675358987",
     id:"1",
     Name:"Chocolate Truffle Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
     PersonName:"Anjali",
     ContactNumber: "675358987",
     id:"2",
     Name:"Black Forest Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
        PersonName:"Anuradha",
     ContactNumber: "675358987",
     id:"3",
     Name:"Fruit Overload Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
        PersonName:"Aman",
     ContactNumber: "675358987",
     id:"4",
     Name:"Red Velvet Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
        PersonName:"Anuja",
        ContactNumber: "675358987",
     id:"5",
     Name:"Butterscotch Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
        PersonName:"Anup",
     ContactNumber: "675358987",
     id:"6",
     Name:"Vanilla Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
        PersonName:"Ajay",
     ContactNumber: "675358987",
     id:"7",
     Name:"Blueberry Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
        PersonName:"Ashmita",
     ContactNumber: "675358987",
     id:"8",
     Name:"Ferrero Rocher Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
        PersonName:"Anushri",
     ContactNumber: "675358987",
     id:"9",
     Name:"White Forest Cake",
     Price:"300",
     Quantity:"500g"
    },
    {
        PersonName:"Anushman",
     ContactNumber: "675358987",
     id:"10",
     Name:"Blueberry Cheese Cake",
     Price:"300",
     Quantity:"500g"
    }
 
 ]
 
 
 
 export default OrderDetails;