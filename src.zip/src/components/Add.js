import React, { useState } from "react";
import {Button, Form} from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.min.css";
import Admin from './Admin';
import {v4 as uuid} from "uuid";
import {Link, useNavigate} from 'react-router-dom';

function Add(){
    const[name, setName] = useState('');
    const[price, setPrice] = useState('');
    const[quantity, setQuantity] = useState('');
    
    let history = useNavigate();

    const handleSubmit =(e) => {
        e.preventDefault();

        const ids = uuid();
        let uniqueId = ids.slice(0,8);

        let a = name,
        b = price,
        c = quantity;

        Admin.push({id:uniqueId, Name: a, Price: b, Quantity: c});
          history("/");
    } 


    return(

        <div>
            <Form className="d-grid gap-2" style={{margin:"15rem"}}>
                <Form.Group className="mb-3" controlId="formName">
                    <Form.Control type="text" placeholder="Enter Cake Name" required onChange={(e) => setName(e.target.value)}>

                    </Form.Control>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formPrice">
                    <Form.Control type="text" placeholder="Enter Price" required onChange={(e) => setPrice(e.target.value)}>
                        
                    </Form.Control>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formQuantity">
                    <Form.Control type="text" placeholder="Enter Quantity" required onChange={(e) => setQuantity(e.target.value)}>
                        
                    </Form.Control>
                </Form.Group>
                <Link to={'/home'}>
                <Button onClick={(e) => handleSubmit(e)} type="submit">Add</Button>
                </Link>
            </Form>
        </div>
    );
}

export default Add;