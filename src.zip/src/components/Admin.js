const Admin = [
   {
    id:"1",
    Name:"Chocolate Truffle Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"2",
    Name:"Black Forest Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"3",
    Name:"Fruit Overload Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"4",
    Name:"Red Velvet Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"5",
    Name:"Butterscotch Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"6",
    Name:"Vanilla Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"7",
    Name:"Blueberry Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"8",
    Name:"Ferrero Rocher Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"9",
    Name:"White Forest Cake",
    Price:"300",
    Quantity:"500g"
   },
   {
    id:"10",
    Name:"Blueberry Cheese Cake",
    Price:"300",
    Quantity:"500g"
   }

]



export default Admin;