import React  from 'react';
import './App.css';
import AdminDashboard from './components/AdminDashboard';
import Home from './components/Home';
import Login from './components/Login';
import Orders from './components/Orders';
import Add from './components/Add';
import Update from './components/Update';
import { BrowserRouter as Router,Route, Routes} from 'react-router-dom';



function App() {
  return (
   <div className='App'>

    
    <Router>
      <Routes>
      {/* <Route path='/login' element={<Login/>}/> */}
      <Route path='/orders' element={<Orders/>}/>
      <Route path='/' element={<Login/>}/>
      <Route path='/logout' element={<AdminDashboard/>}/>
        <Route path='/adminDashboard' element={<AdminDashboard/>}/>
        <Route path='/home' element={<Home />} />
        <Route path='/create' element={<Add />} />
        <Route path='/update' element={<Update />} />
      </Routes>
    </Router>

       

 </div> );
}

export default App;
