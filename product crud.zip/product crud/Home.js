import React, { Fragment } from 'react';
import {Button, Table} from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.min.css";
import Admin from './Admin'; 
import {Link, useNavigate} from 'react-router-dom';
import Header from './Header';

function Home(){

    let history = useNavigate();

    const handleUpdate = (id, name, price, quantity) => {
        localStorage.setItem('Name',name);
        localStorage.setItem('Price',price);
        localStorage.setItem('Quantity',quantity);
        localStorage.setItem('Id',id);
    }

    const handleDelete = (id) =>{
        var index = Admin.map(function(e){
            return e.id
        }).indexOf(id);

        Admin.splice(index,1);
        history('/');
    }

     return(
        
        <Fragment>
            <Header />
            <div style={{margin:"10rem"}}>
               <Table striped bordered hover >
                <thead>
                    <tr>
                        <th>
                            Name
                        </th>
                        <th>
                            Price
                        </th>
                        <th>
                            Quantity
                        </th>
                        <th>
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {
                        Admin && Admin.length > 0?
                        Admin.map((item) =>{
                            return(
                                <tr>
                                    <td>
                                        {item.Name}
                                    </td>
                                    <td>
                                        {item.Price}
                                    </td>
                                    <td>
                                        {item.Quantity}
                                    </td>
                                    <td>
                                        <Link to={'/update'}>
                                        <Button onClick={() => handleUpdate(item.id, item.Name, item.Price, item.Quantity)}>Update</Button>
                                        </Link>
                                        &nbsp;
                                        <Link to={'/home'}>
                                        <Button onClick={() => handleDelete(item.id)}>Delete</Button>
                                        </Link>
                                    </td>
                                </tr>
                            )
                        })
                        :
                        "No record"
                    }
                </tbody>
               </Table>

               <br>
               </br>

               <Link className='d-grid gap-2' to='/create'>
                   <Button size='lg'>Add Cakes</Button>
               </Link>

            </div>
        </Fragment>
     );
}

export default Home;